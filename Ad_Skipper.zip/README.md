# Ad-Skipper
Chrome extension to skip YouTube ads instantaneously without having to wait for the countdown timer.
